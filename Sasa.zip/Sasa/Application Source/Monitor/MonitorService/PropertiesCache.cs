﻿using Microsoft.Win32;
using System;
using System.Collections.Generic;

namespace sasa.common
{
    class PropertiesCache
    {
        private static volatile PropertiesCache instance;
        private static object syncRoot = new object();
        private const string SUB_KEY = "Software\\Sasa-Softwar\\Monitor";
        public const string INSTALL_TYPE = "InstallType";
        public const string SRC_FILE_LOCATION = "FILELOCATION";
        public const string SRC_FILE_NAME = "FILENAME";
        public const string SRC_OVERRIDE_IF_EXIST = "OVERRIDEIFEXIST";
        public const string SRC_FREQUENCY = "FREQUENCY";
        public const string TARGET_FILE_LOCATION = "TRGFILELOCATION";
        public const string TARGET_FILE_NAME = "TRGFILENAME";
        public const string TARGET_DELETE_FILE = "TRGDELETEFILE";
        public const string TARGET_FREQUENCY = "TRGFREQUENCY";
        public const string TARGET_NOTIFICATION_TYPE = "NOTIFICATIONTYPE";
        public const string TARGET_SMTP_HOST = "SMTPHOST";
        public const string TARGET_SMTP_PORT = "SMTPPORT";
        public const string TARGET_SMTP_USER = "SMTPUSER";
        public const string TARGET_SMTP_PASSWORD = "SMTPPASSWORD";
        public const string TARGET_SMTPP_EMAIL = "SMTPEMAIL";
        private string[] REG_NAMES_ARRAY = {INSTALL_TYPE, SRC_FILE_LOCATION, SRC_FILE_NAME, SRC_OVERRIDE_IF_EXIST , SRC_FREQUENCY,
            TARGET_FILE_LOCATION,TARGET_FILE_NAME,TARGET_DELETE_FILE,TARGET_FREQUENCY,TARGET_NOTIFICATION_TYPE,
            TARGET_SMTP_HOST,TARGET_SMTP_PORT,TARGET_SMTP_USER,TARGET_SMTP_PASSWORD,TARGET_SMTPP_EMAIL
        };
        private IDictionary<string, string> regValuesDictionary = new Dictionary<string,string>();

        private PropertiesCache() { ReadFromReg(); }

        public static PropertiesCache Instance
        {
            get
            {
                if (instance == null)
                {
                    lock (syncRoot)
                    {
                        if (instance == null)
                            instance = new PropertiesCache();
                    }
                }
                return instance;
            }
        }

        private void ReadFromReg()
        {
            RegistryKey key = Registry.CurrentUser.OpenSubKey(@SUB_KEY);
            if (key == null)
            {
                throw new System.Exception("Fatatl Error - Registry Key: " + SUB_KEY + " Was not found");
            }

            for(int i=0;i< REG_NAMES_ARRAY.Length;i++)
            {
                string regName = REG_NAMES_ARRAY[i];
                string regValue = (string) key.GetValue(regName);
                regValuesDictionary[regName] = regValue;
            }
            key.Close();

        }


        private void writeToReg(string propertyName, string newValue)
        {
            RegistryKey key = Registry.CurrentUser.OpenSubKey(@SUB_KEY, true);
            if (key == null)
            {
                throw new System.Exception("Fatatl Error - Registry Key: " + SUB_KEY + " Was not found");
            }
            key.SetValue(propertyName, newValue);
            key.Close();
        }

        public string ReadValueFromCache(string propertyName)
        {
            return regValuesDictionary[propertyName];
        }

        public void UpdateProperty(string propertyName,string newValue){
            regValuesDictionary[propertyName] = newValue;
            writeToReg(propertyName, newValue);
        }

    }

}