﻿using sasa.common;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Linq;
using System.ServiceProcess;
using System.Text;
using System.Threading.Tasks;

namespace MonitorService
{
    public partial class SasaMonitor : ServiceBase
    {
        private PropertiesCache cache = PropertiesCache.Instance;

        private MonitorService monitorService;

        public SasaMonitor()
        {
            InitializeComponent();
        }

        protected override void OnStart(string[] args)
        {
            monitorService = MonitorServiceFactory.GetService(cache.ReadValueFromCache(PropertiesCache.INSTALL_TYPE));
            monitorService.Start();
        }

        protected override void OnStop()
        {
            monitorService.Stop();
        }
    }
}
