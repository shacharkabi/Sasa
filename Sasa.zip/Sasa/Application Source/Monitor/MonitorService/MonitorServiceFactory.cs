﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MonitorService
{
    class MonitorServiceFactory
    {
        internal static MonitorService GetService(string serviceType)
        {
            switch (serviceType.ToLower())
            {
                case "src":
                    return SourceMachineService.Instance;
                case "trg":
                    return TargetMachineService.Instance;
                default:
                    return null;

            }
        }

    }
}
