﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MonitorService
{
    class TargetMachineService:MonitorService
    {

        private static volatile TargetMachineService instance;

        private static object syncRoot = new object();

        private TargetMachineService() { }

        public static TargetMachineService Instance
        {
            get
            {
                if (instance == null)
                {
                    lock (syncRoot)
                    {
                        if (instance == null)
                            instance = new TargetMachineService();
                    }
                }
                return instance;
            }
        }

        public void Start()
        {
            throw new NotImplementedException();
        }

        public void Stop()
        {
            throw new NotImplementedException();
        }
    }
}
