﻿using sasa.common;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Timers;

namespace MonitorService
{
    class SourceMachineService : MonitorService
    {
        private static volatile SourceMachineService instance;

        private static object syncRoot = new object();

        private PropertiesCache cache = PropertiesCache.Instance;

        private Timer timer = new Timer();

        private SourceMachineService() { Initialize();}

        private String folderName;

        private String fileName;

        private bool overrideIfExist;

        private long totalFilesSent = 0;


        private void Initialize()
        {
            timer.Interval = int.Parse(cache.ReadValueFromCache(PropertiesCache.SRC_FREQUENCY)) * 1000;
            folderName = cache.ReadValueFromCache(PropertiesCache.SRC_FILE_LOCATION);
            fileName = cache.ReadValueFromCache(PropertiesCache.SRC_FILE_NAME);
            overrideIfExist = isOverrideIfExist(cache.ReadValueFromCache(PropertiesCache.SRC_OVERRIDE_IF_EXIST));
            timer.Elapsed += new ElapsedEventHandler(this.TimerTick);
        }

        private void TimerTick(object sender, ElapsedEventArgs args)
        {
            totalFilesSent++;
            WriteFile();
        }

        private void WriteFile()
        {
            CreateDir();
            CreateOrReplaceFile();
        }

        private void CreateOrReplaceFile()
        {
            String filePath = folderName + "/" + fileName;
            if (!File.Exists(filePath))
            {
                CreateFile(filePath);
            }
            else if (overrideIfExist)
            {
                DeleteFile(filePath);
                CreateFile(filePath);
            }
        }

        private void DeleteFile(string filePath)
        {
            File.Delete(filePath);
        }

        private void CreateFile(string filePath)
        {
            using (StreamWriter sw = File.AppendText(filePath))
            {
                sw.WriteLine(totalFilesSent);
            }
            File.WriteAllText(filePath,totalFilesSent.ToString());
        }

        private void CreateDir()
        {
            if (Directory.Exists(folderName))
            {
                return;
            }
            DirectoryInfo di = Directory.CreateDirectory(folderName);
        }

        private bool isOverrideIfExist(string value)
        {
            if ("1".Equals(value))
            {
                return true;
            }
            return false;
        }

        public static SourceMachineService Instance
        {
            get
            {
                if (instance == null)
                {
                    lock (syncRoot)
                    {
                        if (instance == null)
                            instance = new SourceMachineService();
                    }
                }
                return instance;
            }
        }

        public void Start()
        {
            timer.Start();
        }

        public void Stop()
        {
            timer.Stop();
        }
    }
}
