﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using sasa.cout;
using sasa.common;

namespace Monitor
{
    public partial class SourcePropertiesEdit : UserControl,PropertiesFrame
    {
        SourcePropertiesValidator validator = new SourcePropertiesValidator();

        PropertiesCache propertiesCache = PropertiesCache.Instance;


        public SourcePropertiesEdit()
        {
            InitializeComponent();
            InitializeValues();
            MainForm.GetInstance().SetActiveControl(this);
        }

        public void InitializeValues()
        {
            folderNameTxt.Text = propertiesCache.ReadValueFromCache(PropertiesCache.SRC_FILE_LOCATION);
            fileNameTxt.Text = propertiesCache.ReadValueFromCache(PropertiesCache.SRC_FILE_NAME);
            overrideCkb.Checked = isOverrideIfExist(propertiesCache.ReadValueFromCache(PropertiesCache.SRC_OVERRIDE_IF_EXIST));
            frequencyTxt.Text = propertiesCache.ReadValueFromCache(PropertiesCache.SRC_FREQUENCY);
        }

        private bool isOverrideIfExist(string value)
        {
            if ("1".Equals(value))
            {
                return true;
            }
            return false;
        }

        private void btnBrowse_Click(object sender, EventArgs e)
        {
            FolderBrowserDialog openFileDialog = new FolderBrowserDialog();
            if (openFileDialog.ShowDialog() == System.Windows.Forms.DialogResult.OK)
            {
                string path = openFileDialog.SelectedPath;
                folderNameTxt.Text = path;
            }
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            propertiesCache.UpdateProperty(PropertiesCache.SRC_FILE_LOCATION, folderNameTxt.Text);
            propertiesCache.UpdateProperty(PropertiesCache.SRC_FILE_NAME, fileNameTxt.Text);
            propertiesCache.UpdateProperty(PropertiesCache.SRC_FREQUENCY, frequencyTxt.Text);
            if (overrideCkb.Checked)
            {
                propertiesCache.UpdateProperty(PropertiesCache.SRC_OVERRIDE_IF_EXIST, "1");
            }
            else
            {
                propertiesCache.UpdateProperty(PropertiesCache.SRC_OVERRIDE_IF_EXIST, "0");
            }

            string message = validator.Validate();
            if (!"".Equals(message))
            {
                MainForm.GetInstance().SetVaildateState(false);
                MessageBox.Show(message, "Invalid Installation Properties");
            }
            else
            {
                MainForm.GetInstance().SetVaildateState(true);
                SourceDetails.Instance.InitializeValues();
                MainForm.GetInstance().SetActiveControl(SourceDetails.Instance);
            }
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            string message = validator.Validate();
            if (!"".Equals(message))
            {
                MainForm.GetInstance().SetVaildateState(false);
                MessageBox.Show(message, "Invalid Installation Properties");
            }
            else
            {
                MainForm.GetInstance().SetVaildateState(true);
                MainForm.GetInstance().SetActiveControl(SourceDetails.Instance);
            }
        }
    }
}
