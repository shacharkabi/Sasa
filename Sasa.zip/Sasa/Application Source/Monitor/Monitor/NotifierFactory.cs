﻿using System;
using sasa.cin;

namespace Monitor
{
    public class NotifierFactory
    {
        internal static Notifier GetNotifier(string notifierType)
        {
            switch (notifierType.ToLower())
            {
                case "smtp":
                    return  SmtpNotifier.Instance;
                case "syslog":
                    return SyslogNotifier.Instance;
                case "snmp":
                    return SnmpNotifier.Instance;
                default:
                    return null;

            }
        }

        internal static NotifierDetails GetNotifierDetails(string notifierType)
        {
            switch (notifierType.ToLower())
            {
                case "smtp":
                    return SmtpProperties.Instance;
                case "syslog":
                    return SyslogProperties.Instance;
                case "snmp":
                    return SnmpProperties.Instance;
                default:
                    return null;

            }
        }

    }
}