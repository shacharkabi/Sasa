﻿namespace Monitor
{
    partial class TargetPropertiesEdit
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.folderNameLbl = new System.Windows.Forms.Label();
            this.fileNameLbl = new System.Windows.Forms.Label();
            this.frequencyLbl = new System.Windows.Forms.Label();
            this.notificationTypeLbl = new System.Windows.Forms.Label();
            this.deleteAfterReadLbl = new System.Windows.Forms.Label();
            this.folderNameTxt = new System.Windows.Forms.TextBox();
            this.fileNameTxt = new System.Windows.Forms.TextBox();
            this.frequencyTxt = new System.Windows.Forms.TextBox();
            this.notificationTypeCombo = new System.Windows.Forms.ComboBox();
            this.deleteAfterReadCkb = new System.Windows.Forms.CheckBox();
            this.browseBtn = new System.Windows.Forms.Button();
            this.btnCancel = new System.Windows.Forms.Button();
            this.btnSave = new System.Windows.Forms.Button();
            this.notificationDetailsPnl = new System.Windows.Forms.Panel();
            this.SuspendLayout();
            // 
            // folderNameLbl
            // 
            this.folderNameLbl.AutoSize = true;
            this.folderNameLbl.Location = new System.Drawing.Point(20, 32);
            this.folderNameLbl.Name = "folderNameLbl";
            this.folderNameLbl.Size = new System.Drawing.Size(93, 17);
            this.folderNameLbl.TabIndex = 0;
            this.folderNameLbl.Text = "Folder Name:";
            // 
            // fileNameLbl
            // 
            this.fileNameLbl.AutoSize = true;
            this.fileNameLbl.Location = new System.Drawing.Point(20, 78);
            this.fileNameLbl.Name = "fileNameLbl";
            this.fileNameLbl.Size = new System.Drawing.Size(75, 17);
            this.fileNameLbl.TabIndex = 1;
            this.fileNameLbl.Text = "File Name:";
            // 
            // frequencyLbl
            // 
            this.frequencyLbl.AutoSize = true;
            this.frequencyLbl.Location = new System.Drawing.Point(20, 126);
            this.frequencyLbl.Name = "frequencyLbl";
            this.frequencyLbl.Size = new System.Drawing.Size(79, 17);
            this.frequencyLbl.TabIndex = 2;
            this.frequencyLbl.Text = "Frequency:";
            // 
            // notificationTypeLbl
            // 
            this.notificationTypeLbl.AutoSize = true;
            this.notificationTypeLbl.Location = new System.Drawing.Point(20, 175);
            this.notificationTypeLbl.Name = "notificationTypeLbl";
            this.notificationTypeLbl.Size = new System.Drawing.Size(118, 17);
            this.notificationTypeLbl.TabIndex = 3;
            this.notificationTypeLbl.Text = "Notification Type:";
            // 
            // deleteAfterReadLbl
            // 
            this.deleteAfterReadLbl.AutoSize = true;
            this.deleteAfterReadLbl.Location = new System.Drawing.Point(20, 226);
            this.deleteAfterReadLbl.Name = "deleteAfterReadLbl";
            this.deleteAfterReadLbl.Size = new System.Drawing.Size(125, 17);
            this.deleteAfterReadLbl.TabIndex = 4;
            this.deleteAfterReadLbl.Text = "Delete After Read:";
            // 
            // folderNameTxt
            // 
            this.folderNameTxt.Enabled = false;
            this.folderNameTxt.Location = new System.Drawing.Point(158, 32);
            this.folderNameTxt.Name = "folderNameTxt";
            this.folderNameTxt.Size = new System.Drawing.Size(538, 22);
            this.folderNameTxt.TabIndex = 5;
            // 
            // fileNameTxt
            // 
            this.fileNameTxt.Location = new System.Drawing.Point(158, 78);
            this.fileNameTxt.Name = "fileNameTxt";
            this.fileNameTxt.Size = new System.Drawing.Size(538, 22);
            this.fileNameTxt.TabIndex = 6;
            // 
            // frequencyTxt
            // 
            this.frequencyTxt.Location = new System.Drawing.Point(158, 121);
            this.frequencyTxt.Name = "frequencyTxt";
            this.frequencyTxt.Size = new System.Drawing.Size(538, 22);
            this.frequencyTxt.TabIndex = 7;
            // 
            // notificationTypeCombo
            // 
            this.notificationTypeCombo.FormattingEnabled = true;
            this.notificationTypeCombo.Items.AddRange(new object[] {
            "SMTP",
            "SYSLOG",
            "SNMP"});
            this.notificationTypeCombo.Location = new System.Drawing.Point(158, 172);
            this.notificationTypeCombo.Name = "notificationTypeCombo";
            this.notificationTypeCombo.Size = new System.Drawing.Size(538, 24);
            this.notificationTypeCombo.TabIndex = 8;
            this.notificationTypeCombo.SelectedIndexChanged += new System.EventHandler(this.notificationTypeCombo_SelectedIndexChanged);
            // 
            // deleteAfterReadCkb
            // 
            this.deleteAfterReadCkb.AutoSize = true;
            this.deleteAfterReadCkb.Location = new System.Drawing.Point(158, 226);
            this.deleteAfterReadCkb.Name = "deleteAfterReadCkb";
            this.deleteAfterReadCkb.Size = new System.Drawing.Size(18, 17);
            this.deleteAfterReadCkb.TabIndex = 9;
            this.deleteAfterReadCkb.UseVisualStyleBackColor = true;
            // 
            // browseBtn
            // 
            this.browseBtn.Location = new System.Drawing.Point(712, 32);
            this.browseBtn.Name = "browseBtn";
            this.browseBtn.Size = new System.Drawing.Size(84, 22);
            this.browseBtn.TabIndex = 10;
            this.browseBtn.Text = "Browse";
            this.browseBtn.UseVisualStyleBackColor = true;
            this.browseBtn.Click += new System.EventHandler(this.browseBtn_Click);
            // 
            // btnCancel
            // 
            this.btnCancel.Location = new System.Drawing.Point(712, 483);
            this.btnCancel.Name = "btnCancel";
            this.btnCancel.Size = new System.Drawing.Size(84, 22);
            this.btnCancel.TabIndex = 11;
            this.btnCancel.Text = "Cancel";
            this.btnCancel.UseVisualStyleBackColor = true;
            this.btnCancel.Click += new System.EventHandler(this.btnCancel_Click);
            // 
            // btnSave
            // 
            this.btnSave.Location = new System.Drawing.Point(612, 483);
            this.btnSave.Name = "btnSave";
            this.btnSave.Size = new System.Drawing.Size(84, 22);
            this.btnSave.TabIndex = 12;
            this.btnSave.Text = "Save";
            this.btnSave.UseVisualStyleBackColor = true;
            this.btnSave.Click += new System.EventHandler(this.btnSave_Click);
            // 
            // notificationDetailsPnl
            // 
            this.notificationDetailsPnl.Location = new System.Drawing.Point(23, 260);
            this.notificationDetailsPnl.Name = "notificationDetailsPnl";
            this.notificationDetailsPnl.Size = new System.Drawing.Size(673, 217);
            this.notificationDetailsPnl.TabIndex = 13;
            // 
            // TargetPropertiesEdit
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.notificationDetailsPnl);
            this.Controls.Add(this.btnSave);
            this.Controls.Add(this.btnCancel);
            this.Controls.Add(this.browseBtn);
            this.Controls.Add(this.deleteAfterReadCkb);
            this.Controls.Add(this.notificationTypeCombo);
            this.Controls.Add(this.frequencyTxt);
            this.Controls.Add(this.fileNameTxt);
            this.Controls.Add(this.folderNameTxt);
            this.Controls.Add(this.deleteAfterReadLbl);
            this.Controls.Add(this.notificationTypeLbl);
            this.Controls.Add(this.frequencyLbl);
            this.Controls.Add(this.fileNameLbl);
            this.Controls.Add(this.folderNameLbl);
            this.Name = "TargetPropertiesEdit";
            this.Size = new System.Drawing.Size(826, 517);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label folderNameLbl;
        private System.Windows.Forms.Label fileNameLbl;
        private System.Windows.Forms.Label frequencyLbl;
        private System.Windows.Forms.Label notificationTypeLbl;
        private System.Windows.Forms.Label deleteAfterReadLbl;
        private System.Windows.Forms.TextBox folderNameTxt;
        private System.Windows.Forms.TextBox fileNameTxt;
        private System.Windows.Forms.TextBox frequencyTxt;
        private System.Windows.Forms.ComboBox notificationTypeCombo;
        private System.Windows.Forms.CheckBox deleteAfterReadCkb;
        private System.Windows.Forms.Button browseBtn;
        private System.Windows.Forms.Button btnCancel;
        private System.Windows.Forms.Button btnSave;
        private System.Windows.Forms.Panel notificationDetailsPnl;
    }
}
