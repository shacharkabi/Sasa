﻿using sasa.common;
using System;

namespace Monitor
{
    public class TargetPropertiesValidator : PropertiesValidator
    {
        PropertiesCache cache = PropertiesCache.Instance;

        override
      public string Validate()
        {
            string message = "";
            message = message + ValidateFolder(cache.ReadValueFromCache(PropertiesCache.TARGET_FILE_LOCATION));
            message = message + ValidateFile(cache.ReadValueFromCache(PropertiesCache.TARGET_FILE_NAME));
            message = message + ValidateNumber(cache.ReadValueFromCache(PropertiesCache.TARGET_FREQUENCY));
            return message;
        }
    }
}