﻿using System;
using System.IO;

namespace sasa.common
{
    public abstract class PropertiesValidator
    {
         public abstract string Validate(); 

        public string ValidateFolder(string path)
        {
            try
            {
                if (Path.IsPathRooted(path)) {
                    Path.GetFullPath(path);
                }
                else
                {
                    return "The folder: \"" + path + "\" is not a valid folder.\n";
                }
            }catch(System.Exception e)
            {
                Console.WriteLine(e.StackTrace);
                return "The folder: \"" + path + "\" is not a valid folder.\n";
            }
            return "";
        }

        public string ValidateFile(string fileName)
        {
            if(fileName.IndexOfAny(Path.GetInvalidFileNameChars()) >= 0){
                return "The file name: \"" + fileName + "\" is not a valid file name.\n";
            }
            return "";
        }

        public string ValidateNumber(string number)
        {
            if(int.TryParse(number, out int num) && num>0)
            {
                return "";
            }
            return "The number: \"" + number + "\" is not a valid positive number.\n";
        }

    }

}