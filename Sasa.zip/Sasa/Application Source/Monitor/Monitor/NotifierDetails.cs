﻿namespace Monitor
{
    public interface NotifierDetails
    {
        void Save();

    }
}