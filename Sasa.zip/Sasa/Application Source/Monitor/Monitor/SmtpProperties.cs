﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using sasa.common;

namespace Monitor
{
    public partial class SmtpProperties : UserControl, NotifierDetails
    {
        private static SmtpProperties instance;

        private PropertiesCache cache = PropertiesCache.Instance;

        private static object syncRoot = new object();

        private SmtpProperties()
        {
            InitializeComponent();
            InitializeValues();
        }

        private void InitializeValues()
        {
            smtpHostTxt.Text = cache.ReadValueFromCache(PropertiesCache.TARGET_SMTP_HOST);
            smtpPortTxt.Text = cache.ReadValueFromCache(PropertiesCache.TARGET_SMTP_PORT);
            smtpUserTxt.Text = cache.ReadValueFromCache(PropertiesCache.TARGET_SMTP_USER);
            smtpPasswordTxt.Text = cache.ReadValueFromCache(PropertiesCache.TARGET_SMTP_PASSWORD);
            sendToEmailTxt.Text = cache.ReadValueFromCache(PropertiesCache.TARGET_SMTPP_EMAIL);
        }

        public void Save()
        {
            cache.UpdateProperty(PropertiesCache.TARGET_SMTP_HOST, smtpHostTxt.Text);
            cache.UpdateProperty(PropertiesCache.TARGET_SMTP_PORT, smtpPortTxt.Text);
            cache.UpdateProperty(PropertiesCache.TARGET_SMTP_USER, smtpUserTxt.Text);
            cache.UpdateProperty(PropertiesCache.TARGET_SMTP_PASSWORD, smtpPasswordTxt.Text);
            cache.UpdateProperty(PropertiesCache.TARGET_SMTPP_EMAIL, sendToEmailTxt.Text);
        }

        public static SmtpProperties Instance
        {
            get
            {
                if (instance == null)
                {
                    lock (syncRoot)
                    {
                        if (instance == null)
                            instance = new SmtpProperties();
                    }
                }
                return instance;
            }
        }
    }
}
