﻿using System.Windows.Forms;

namespace Monitor
{
    public interface MainFrame
    {
        void Start();

        void Stop();

        void ValidateProperties();
        void clearEventLogs();
        void exportEventsToFile(string fileName);
    }
}