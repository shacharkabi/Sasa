﻿using sasa.common;

namespace sasa.cout
{

    class SourcePropertiesValidator : PropertiesValidator
    {
        PropertiesCache cache = PropertiesCache.Instance;

        override
        public string Validate()
        {
            string message="";
            message = message +  ValidateFolder(cache.ReadValueFromCache(PropertiesCache.SRC_FILE_LOCATION));
            message = message + ValidateFile(cache.ReadValueFromCache(PropertiesCache.SRC_FILE_NAME));
            message = message + ValidateNumber(cache.ReadValueFromCache(PropertiesCache.SRC_FREQUENCY));
            return message;
        }
    }
}