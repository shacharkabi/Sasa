﻿using sasa.cin;
using Rebex.Net;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using sasa.common;

namespace Monitor
{
    class SyslogNotifier : Notifier
    {
        private static SyslogNotifier instance;

        private static object syncRoot = new object();

        private PropertiesCache cache = PropertiesCache.Instance;

        public bool SendNotification()
        {
            try
            {
                string sysLogHost = cache.ReadValueFromCache(PropertiesCache.TARGET_SYSLOG_HOST);
                int sysLogPort = int.Parse(cache.ReadValueFromCache(PropertiesCache.TARGET_SYSLOG_PORT));
                Syslog client = new Syslog(TransportProtocol.Udp, sysLogHost, sysLogPort);
                SyslogMessage msg = new SyslogMessage();
                msg.Facility = FacilityLevel.User;
                msg.Severity = SeverityLevel.Debug;
                msg.Text = PropertiesCache.DEFAULT_MESSAGE;
                client.Send(msg);
                client.Close();
            }
            catch(Exception)
            {
                return false;
            }
            return true;
        }

        public static SyslogNotifier Instance
        {
            get
            {
                if (instance == null)
                {
                    lock (syncRoot)
                    {
                        if (instance == null)
                            instance = new SyslogNotifier();
                    }
                }
                return instance;
            }
        }
    }
}
