﻿using sasa.cin;
using sasa.common;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Mail;
using System.Text;
using System.Threading.Tasks;

namespace Monitor
{
    class SmtpNotifier : Notifier
    {
        private static SmtpNotifier instance;

        private static object syncRoot = new object();

        private PropertiesCache cache = PropertiesCache.Instance;

        public bool SendNotification()
        {
            try
            {
                MailMessage mail = new MailMessage();
                mail.To.Add(cache.ReadValueFromCache(PropertiesCache.TARGET_SMTPP_EMAIL));
                mail.From = new MailAddress(cache.ReadValueFromCache(PropertiesCache.TARGET_SMTP_USER));
                mail.Subject = "Sasa-Monitor Detected Failure";
                mail.Body = PropertiesCache.DEFAULT_MESSAGE;
                mail.IsBodyHtml = true;
                SmtpClient smtp = new SmtpClient(cache.ReadValueFromCache(PropertiesCache.TARGET_SMTP_HOST), int.Parse(cache.ReadValueFromCache(PropertiesCache.TARGET_SMTP_PORT)));
                smtp.EnableSsl = true;
                smtp.UseDefaultCredentials = false;
                smtp.Credentials = new System.Net.NetworkCredential(cache.ReadValueFromCache(PropertiesCache.TARGET_SMTP_USER), cache.ReadValueFromCache(PropertiesCache.TARGET_SMTP_PASSWORD));
                smtp.Send(mail);
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.ToString());
            }
            return true;
        }

        public static SmtpNotifier Instance
        {
            get
            {
                if (instance == null)
                {
                    lock (syncRoot)
                    {
                        if (instance == null)
                            instance = new SmtpNotifier();
                    }
                }
                return instance;
            }
        }
    }
}
