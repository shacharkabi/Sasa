﻿namespace Monitor
{
    public interface PropertiesFrame
    {
    }
}