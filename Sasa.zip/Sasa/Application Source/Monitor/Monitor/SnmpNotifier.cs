﻿using sasa.cin;
using sasa.common;
using SnmpSharpNet;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Monitor
{
    class SnmpNotifier : Notifier
    {
        private static SnmpNotifier instance;

        private static object syncRoot = new object();

        private PropertiesCache cache = PropertiesCache.Instance;

        public bool SendNotification()
        {
            try
            {
                string snmpHost = cache.ReadValueFromCache(PropertiesCache.TARGET_SNMP_HOST);
                int snmpPort = int.Parse(cache.ReadValueFromCache(PropertiesCache.TARGET_SNMP_PORT));
                TrapAgent agent = new TrapAgent();
                VbCollection col = new VbCollection();
                col.Add(new Oid("1.3.6.1.2.1.1.1.0"), new OctetString(PropertiesCache.DEFAULT_MESSAGE));
                agent.SendV1Trap(new IpAddress(snmpHost), snmpPort, "public",
                new Oid("1.3.6.1.2.1.1.1.0"), new IpAddress("127.0.0.1"),
                SnmpConstants.LinkDown, SnmpConstants.ErrResourceUnavailable, 13432, col);
                return true;
            }catch(Exception)
            {
                return false;
            }
        }

        public static SnmpNotifier Instance
        {
            get
            {
                if (instance == null)
                {
                    lock (syncRoot)
                    {
                        if (instance == null)
                            instance = new SnmpNotifier();
                    }
                }
                return instance;
            }
        }
    }
}
