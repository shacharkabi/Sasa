﻿namespace Monitor
{
    partial class SnmpProperties
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.snmpHostLbl = new System.Windows.Forms.Label();
            this.snmpPortLbl = new System.Windows.Forms.Label();
            this.snmpHostTxt = new System.Windows.Forms.TextBox();
            this.snmpPortTxt = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // snmpHostLbl
            // 
            this.snmpHostLbl.AutoSize = true;
            this.snmpHostLbl.Location = new System.Drawing.Point(21, 17);
            this.snmpHostLbl.Name = "snmpHostLbl";
            this.snmpHostLbl.Size = new System.Drawing.Size(84, 17);
            this.snmpHostLbl.TabIndex = 1;
            this.snmpHostLbl.Text = "SNMP Host:";
            // 
            // snmpPortLbl
            // 
            this.snmpPortLbl.AutoSize = true;
            this.snmpPortLbl.Location = new System.Drawing.Point(21, 54);
            this.snmpPortLbl.Name = "snmpPortLbl";
            this.snmpPortLbl.Size = new System.Drawing.Size(81, 17);
            this.snmpPortLbl.TabIndex = 2;
            this.snmpPortLbl.Text = "SNMP Port:";
            // 
            // snmpHostTxt
            // 
            this.snmpHostTxt.Location = new System.Drawing.Point(152, 17);
            this.snmpHostTxt.Name = "snmpHostTxt";
            this.snmpHostTxt.Size = new System.Drawing.Size(495, 22);
            this.snmpHostTxt.TabIndex = 3;
            // 
            // snmpPortTxt
            // 
            this.snmpPortTxt.Location = new System.Drawing.Point(152, 54);
            this.snmpPortTxt.Name = "snmpPortTxt";
            this.snmpPortTxt.Size = new System.Drawing.Size(495, 22);
            this.snmpPortTxt.TabIndex = 4;
            // 
            // SnmpProperties
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.Controls.Add(this.snmpPortTxt);
            this.Controls.Add(this.snmpHostTxt);
            this.Controls.Add(this.snmpPortLbl);
            this.Controls.Add(this.snmpHostLbl);
            this.Name = "SnmpProperties";
            this.Size = new System.Drawing.Size(669, 193);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label snmpHostLbl;
        private System.Windows.Forms.Label snmpPortLbl;
        private System.Windows.Forms.TextBox snmpHostTxt;
        private System.Windows.Forms.TextBox snmpPortTxt;
    }
}
