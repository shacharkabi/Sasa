﻿using sasa.common;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.Office.Interop.Word;
using System.IO;

namespace Monitor
{
    public partial class MainForm : Form
    {
        private static MainForm instance;

        private PropertiesCache cache = PropertiesCache.Instance;

        private Control mainFrame;

        private String helpTempFileName = Path.GetTempPath() + "sasaHelp";

        public MainForm()
        {
            InitializeComponent();
        }

        public static MainForm GetInstance()
        {
            return instance;
        }

        public void SetActiveControl(Control activeControl)
        {
            mainPanel.Controls.Clear();
            mainPanel.Controls.Add(activeControl);
        }

        private void MainForm_Resize(object sender, EventArgs e)
        {
            notifyIcon1.BalloonTipTitle = "Sasa-Monitor 1.0";
            notifyIcon1.BalloonTipText = "Sasa-Monitor will keep runnig in background";

            if (FormWindowState.Minimized == this.WindowState)
            {
                notifyIcon1.Visible = true;
                notifyIcon1.ShowBalloonTip(500);
                this.Hide();
            }
            else if (FormWindowState.Normal == this.WindowState)
            {
                notifyIcon1.Visible = false;
            }
        }

        private void notifyIcon1_MouseDoubleClick(object sender, MouseEventArgs e)
        {
            this.Show();
            this.WindowState = FormWindowState.Normal;
        }

        internal void SetVaildateState(bool isValid)
        {
            startMenuItem.Enabled = isValid;
            startToolStripMenuItem.Enabled = isValid;
        }

        private void startToolStripMenuItem_Click(object sender, EventArgs e)
        {
            doStart();
        }

        private void doStart()
        {
            ((MainFrame)mainFrame).Start();
            EnableStart(false);
        }

        private void stopToolStripMenuItem_Click(object sender, EventArgs e)
        {
            doStop();
        }

        private void doStop()
        {

            ((MainFrame)mainFrame).Stop();
            EnableStart(true);
        }

        public void EnableStart(bool enable)
        {
            if (enable)
            {
                this.notifyIcon1.Icon = ((System.Drawing.Icon)(Properties.Resources.stop));
            }
            else
            {
                this.notifyIcon1.Icon = ((System.Drawing.Icon)(Properties.Resources.run));
            }
            startToolStripMenuItem.Enabled = startMenuItem.Enabled = enable;
            stopToolStripMenuItem.Enabled = stopMenuItem.Enabled = !enable;
        }

        private void startMenuItem_Click(object sender, EventArgs e)
        {
            doStart();
        }

        private void stopMenuItem_Click(object sender, EventArgs e)
        {
            doStop();
        }

        private void userManualToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (!File.Exists(helpTempFileName))
            {
                File.WriteAllBytes(helpTempFileName, Properties.Resources.Sasa_Monitor);
            }
            Microsoft.Office.Interop.Word.Application app = new Microsoft.Office.Interop.Word.Application();
            Document doc = app.Documents.Open(helpTempFileName);
            app.Visible = true;
        }

        private void exitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void MainForm_Shown(object sender, EventArgs e)
        {
            instance = this;
            string targetFolder = cache.ReadValueFromCache(PropertiesCache.TARGET_FILE_LOCATION);
            string sourceFolder = cache.ReadValueFromCache(PropertiesCache.SRC_FILE_LOCATION);
            if (!string.IsNullOrEmpty(sourceFolder))
            {
                mainFrame = SourceDetails.Instance;
            }
            else if (!string.IsNullOrEmpty(targetFolder))
            {
                mainFrame = TargetDetails.Instance;
            }
            SetActiveControl(mainFrame);
            ((MainFrame)mainFrame).ValidateProperties();
        }

        private void clearToolStripMenuItem_Click(object sender, EventArgs e)
        {
            ((MainFrame)mainFrame).clearEventLogs();
        }

        private void exportToFileToolStripMenuItem_Click(object sender, EventArgs e)
        {
            SaveFileDialog SaveFileDialog1 = new SaveFileDialog();
            SaveFileDialog1.OverwritePrompt = true;
            SaveFileDialog1.FileName = "monitorEvents.txt";
            SaveFileDialog1.Filter = "Text files (*.txt)|*.txt";
            SaveFileDialog1.InitialDirectory = Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments);
            DialogResult result = SaveFileDialog1.ShowDialog();
            if (result == DialogResult.OK)
            {
                ((MainFrame)mainFrame).exportEventsToFile(SaveFileDialog1.FileName);
            }
        }
    }
}
