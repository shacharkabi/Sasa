﻿namespace Monitor
{
    partial class SourceDetails
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.overrideCkb = new System.Windows.Forms.GroupBox();
            this.btnEdit = new System.Windows.Forms.Button();
            this.overrideCkbox = new System.Windows.Forms.CheckBox();
            this.frequencyTxt = new System.Windows.Forms.TextBox();
            this.fileNameTxt = new System.Windows.Forms.TextBox();
            this.folderNameTxt = new System.Windows.Forms.TextBox();
            this.frequencyLbl = new System.Windows.Forms.Label();
            this.overridelbl = new System.Windows.Forms.Label();
            this.fileNameLbl = new System.Windows.Forms.Label();
            this.fileLocationLbl = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.eventsListBox = new System.Windows.Forms.ListBox();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.totaltrxTxt = new System.Windows.Forms.Label();
            this.lastTrxTxt = new System.Windows.Forms.Label();
            this.btnStop = new System.Windows.Forms.Button();
            this.btnStart = new System.Windows.Forms.Button();
            this.totalTrxLbl = new System.Windows.Forms.Label();
            this.lastTrxLbl = new System.Windows.Forms.Label();
            this.stateTxt = new System.Windows.Forms.Label();
            this.stateLbl = new System.Windows.Forms.Label();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.toolTip1 = new System.Windows.Forms.ToolTip(this.components);
            this.overrideCkb.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.SuspendLayout();
            // 
            // overrideCkb
            // 
            this.overrideCkb.Controls.Add(this.btnEdit);
            this.overrideCkb.Controls.Add(this.overrideCkbox);
            this.overrideCkb.Controls.Add(this.frequencyTxt);
            this.overrideCkb.Controls.Add(this.fileNameTxt);
            this.overrideCkb.Controls.Add(this.folderNameTxt);
            this.overrideCkb.Controls.Add(this.frequencyLbl);
            this.overrideCkb.Controls.Add(this.overridelbl);
            this.overrideCkb.Controls.Add(this.fileNameLbl);
            this.overrideCkb.Controls.Add(this.fileLocationLbl);
            this.overrideCkb.Location = new System.Drawing.Point(15, 18);
            this.overrideCkb.Name = "overrideCkb";
            this.overrideCkb.Size = new System.Drawing.Size(447, 238);
            this.overrideCkb.TabIndex = 0;
            this.overrideCkb.TabStop = false;
            this.overrideCkb.Text = "Source Machine Properties";
            // 
            // btnEdit
            // 
            this.btnEdit.Location = new System.Drawing.Point(350, 199);
            this.btnEdit.Name = "btnEdit";
            this.btnEdit.Size = new System.Drawing.Size(80, 33);
            this.btnEdit.TabIndex = 8;
            this.btnEdit.Text = "Edit";
            this.btnEdit.UseVisualStyleBackColor = true;
            this.btnEdit.Click += new System.EventHandler(this.btnEdit_Click);
            // 
            // overrideCkbox
            // 
            this.overrideCkbox.AutoSize = true;
            this.overrideCkbox.Location = new System.Drawing.Point(129, 131);
            this.overrideCkbox.Name = "overrideCkbox";
            this.overrideCkbox.Size = new System.Drawing.Size(18, 17);
            this.overrideCkbox.TabIndex = 7;
            this.overrideCkbox.UseVisualStyleBackColor = true;
            // 
            // frequencyTxt
            // 
            this.frequencyTxt.Location = new System.Drawing.Point(129, 171);
            this.frequencyTxt.Name = "frequencyTxt";
            this.frequencyTxt.ReadOnly = true;
            this.frequencyTxt.Size = new System.Drawing.Size(301, 22);
            this.frequencyTxt.TabIndex = 6;
            // 
            // fileNameTxt
            // 
            this.fileNameTxt.Location = new System.Drawing.Point(129, 85);
            this.fileNameTxt.Name = "fileNameTxt";
            this.fileNameTxt.ReadOnly = true;
            this.fileNameTxt.Size = new System.Drawing.Size(301, 22);
            this.fileNameTxt.TabIndex = 5;
            // 
            // folderNameTxt
            // 
            this.folderNameTxt.Location = new System.Drawing.Point(129, 41);
            this.folderNameTxt.Name = "folderNameTxt";
            this.folderNameTxt.ReadOnly = true;
            this.folderNameTxt.Size = new System.Drawing.Size(301, 22);
            this.folderNameTxt.TabIndex = 4;
            // 
            // frequencyLbl
            // 
            this.frequencyLbl.AutoSize = true;
            this.frequencyLbl.Location = new System.Drawing.Point(16, 176);
            this.frequencyLbl.Name = "frequencyLbl";
            this.frequencyLbl.Size = new System.Drawing.Size(79, 17);
            this.frequencyLbl.TabIndex = 3;
            this.frequencyLbl.Text = "Frequency:";
            this.toolTip1.SetToolTip(this.frequencyLbl, "The frequency that the process should create the file.");
            // 
            // overridelbl
            // 
            this.overridelbl.AutoSize = true;
            this.overridelbl.Location = new System.Drawing.Point(16, 130);
            this.overridelbl.Name = "overridelbl";
            this.overridelbl.Size = new System.Drawing.Size(107, 17);
            this.overridelbl.TabIndex = 2;
            this.overridelbl.Text = "Override If Exist";
            this.toolTip1.SetToolTip(this.overridelbl, "Indicate whether the process should overwrite the file if the file is already exi" +
        "st.");
            // 
            // fileNameLbl
            // 
            this.fileNameLbl.AutoSize = true;
            this.fileNameLbl.Location = new System.Drawing.Point(16, 85);
            this.fileNameLbl.Name = "fileNameLbl";
            this.fileNameLbl.Size = new System.Drawing.Size(75, 17);
            this.fileNameLbl.TabIndex = 1;
            this.fileNameLbl.Text = "File Name:";
            this.toolTip1.SetToolTip(this.fileNameLbl, "The file name that the process should create.");
            // 
            // fileLocationLbl
            // 
            this.fileLocationLbl.AutoSize = true;
            this.fileLocationLbl.Location = new System.Drawing.Point(16, 41);
            this.fileLocationLbl.Name = "fileLocationLbl";
            this.fileLocationLbl.Size = new System.Drawing.Size(92, 17);
            this.fileLocationLbl.TabIndex = 0;
            this.fileLocationLbl.Text = "File Location:";
            this.toolTip1.SetToolTip(this.fileLocationLbl, "The folder where the process should write the file.");
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.eventsListBox);
            this.groupBox1.Location = new System.Drawing.Point(15, 262);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(763, 242);
            this.groupBox1.TabIndex = 1;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Event Console:";
            // 
            // eventsListBox
            // 
            this.eventsListBox.FormattingEnabled = true;
            this.eventsListBox.ItemHeight = 16;
            this.eventsListBox.Location = new System.Drawing.Point(7, 22);
            this.eventsListBox.Name = "eventsListBox";
            this.eventsListBox.Size = new System.Drawing.Size(750, 212);
            this.eventsListBox.TabIndex = 0;
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.totaltrxTxt);
            this.groupBox2.Controls.Add(this.lastTrxTxt);
            this.groupBox2.Controls.Add(this.btnStop);
            this.groupBox2.Controls.Add(this.btnStart);
            this.groupBox2.Controls.Add(this.totalTrxLbl);
            this.groupBox2.Controls.Add(this.lastTrxLbl);
            this.groupBox2.Controls.Add(this.stateTxt);
            this.groupBox2.Controls.Add(this.stateLbl);
            this.groupBox2.Location = new System.Drawing.Point(469, 18);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(309, 238);
            this.groupBox2.TabIndex = 2;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "States:";
            // 
            // totaltrxTxt
            // 
            this.totaltrxTxt.AutoSize = true;
            this.totaltrxTxt.Location = new System.Drawing.Point(145, 130);
            this.totaltrxTxt.Name = "totaltrxTxt";
            this.totaltrxTxt.Size = new System.Drawing.Size(16, 17);
            this.totaltrxTxt.TabIndex = 12;
            this.totaltrxTxt.Text = "0";
            // 
            // lastTrxTxt
            // 
            this.lastTrxTxt.AutoSize = true;
            this.lastTrxTxt.Location = new System.Drawing.Point(141, 90);
            this.lastTrxTxt.Name = "lastTrxTxt";
            this.lastTrxTxt.Size = new System.Drawing.Size(31, 17);
            this.lastTrxTxt.TabIndex = 11;
            this.lastTrxTxt.Text = "N/A";
            // 
            // btnStop
            // 
            this.btnStop.Enabled = false;
            this.btnStop.Location = new System.Drawing.Point(223, 199);
            this.btnStop.Name = "btnStop";
            this.btnStop.Size = new System.Drawing.Size(80, 33);
            this.btnStop.TabIndex = 10;
            this.btnStop.Text = "Stop";
            this.btnStop.UseVisualStyleBackColor = true;
            this.btnStop.Click += new System.EventHandler(this.btnStop_Click);
            // 
            // btnStart
            // 
            this.btnStart.Location = new System.Drawing.Point(137, 199);
            this.btnStart.Name = "btnStart";
            this.btnStart.Size = new System.Drawing.Size(80, 33);
            this.btnStart.TabIndex = 9;
            this.btnStart.Text = "Start";
            this.btnStart.UseVisualStyleBackColor = true;
            this.btnStart.Click += new System.EventHandler(this.btnStart_Click);
            // 
            // totalTrxLbl
            // 
            this.totalTrxLbl.AutoSize = true;
            this.totalTrxLbl.Location = new System.Drawing.Point(16, 131);
            this.totalTrxLbl.Name = "totalTrxLbl";
            this.totalTrxLbl.Size = new System.Drawing.Size(123, 17);
            this.totalTrxLbl.TabIndex = 3;
            this.totalTrxLbl.Text = "Total Transaction:";
            // 
            // lastTrxLbl
            // 
            this.lastTrxLbl.AutoSize = true;
            this.lastTrxLbl.Location = new System.Drawing.Point(16, 88);
            this.lastTrxLbl.Name = "lastTrxLbl";
            this.lastTrxLbl.Size = new System.Drawing.Size(118, 17);
            this.lastTrxLbl.TabIndex = 2;
            this.lastTrxLbl.Text = "Last Transaction:";
            // 
            // stateTxt
            // 
            this.stateTxt.AutoSize = true;
            this.stateTxt.Location = new System.Drawing.Point(141, 41);
            this.stateTxt.Name = "stateTxt";
            this.stateTxt.Size = new System.Drawing.Size(61, 17);
            this.stateTxt.TabIndex = 1;
            this.stateTxt.Text = "Stopped";
            // 
            // stateLbl
            // 
            this.stateLbl.AutoSize = true;
            this.stateLbl.Location = new System.Drawing.Point(16, 41);
            this.stateLbl.Name = "stateLbl";
            this.stateLbl.Size = new System.Drawing.Size(45, 17);
            this.stateLbl.TabIndex = 0;
            this.stateLbl.Text = "State:";
            // 
            // timer1
            // 
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // toolTip1
            // 
            this.toolTip1.IsBalloon = true;
            // 
            // SourceDetails
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.overrideCkb);
            this.Name = "SourceDetails";
            this.Size = new System.Drawing.Size(795, 507);
            this.overrideCkb.ResumeLayout(false);
            this.overrideCkb.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox overrideCkb;
        private System.Windows.Forms.Label fileLocationLbl;
        private System.Windows.Forms.Label fileNameLbl;
        private System.Windows.Forms.Label overridelbl;
        private System.Windows.Forms.Label frequencyLbl;
        private System.Windows.Forms.TextBox folderNameTxt;
        private System.Windows.Forms.TextBox fileNameTxt;
        private System.Windows.Forms.TextBox frequencyTxt;
        private System.Windows.Forms.CheckBox overrideCkbox;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.ListBox eventsListBox;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Button btnEdit;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.Label stateLbl;
        private System.Windows.Forms.Label stateTxt;
        private System.Windows.Forms.Label lastTrxLbl;
        private System.Windows.Forms.Label totalTrxLbl;
        private System.Windows.Forms.Button btnStop;
        private System.Windows.Forms.Button btnStart;
        private System.Windows.Forms.Label lastTrxTxt;
        private System.Windows.Forms.Label totaltrxTxt;
        private System.Windows.Forms.ToolTip toolTip1;
    }
}
