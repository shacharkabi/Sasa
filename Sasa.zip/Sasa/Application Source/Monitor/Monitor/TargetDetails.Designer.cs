﻿namespace Monitor
{
    partial class TargetDetails
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.folderNameLbl = new System.Windows.Forms.Label();
            this.fileNameLbl = new System.Windows.Forms.Label();
            this.frequencyLbl = new System.Windows.Forms.Label();
            this.notificationtypeLbl = new System.Windows.Forms.Label();
            this.deleteAfterReadLbl = new System.Windows.Forms.Label();
            this.notificationTypeTxt = new System.Windows.Forms.TextBox();
            this.frequencyTxt = new System.Windows.Forms.TextBox();
            this.fileNameTxt = new System.Windows.Forms.TextBox();
            this.folderNameTxt = new System.Windows.Forms.TextBox();
            this.deleteAfterReadCkb = new System.Windows.Forms.CheckBox();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.btnedit = new System.Windows.Forms.Button();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.btnStop = new System.Windows.Forms.Button();
            this.btnStart = new System.Windows.Forms.Button();
            this.totalTrxTxt = new System.Windows.Forms.Label();
            this.lastFailedtxt = new System.Windows.Forms.Label();
            this.lastSuccessTxt = new System.Windows.Forms.Label();
            this.stateTxt = new System.Windows.Forms.Label();
            this.toalTrxLbl = new System.Windows.Forms.Label();
            this.lastFailedLbl = new System.Windows.Forms.Label();
            this.lastSuccessRead = new System.Windows.Forms.Label();
            this.stateLbl = new System.Windows.Forms.Label();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.eventListBox = new System.Windows.Forms.ListBox();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.toolTip = new System.Windows.Forms.ToolTip(this.components);
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.SuspendLayout();
            // 
            // folderNameLbl
            // 
            this.folderNameLbl.AutoSize = true;
            this.folderNameLbl.Location = new System.Drawing.Point(18, 28);
            this.folderNameLbl.Name = "folderNameLbl";
            this.folderNameLbl.Size = new System.Drawing.Size(93, 17);
            this.folderNameLbl.TabIndex = 0;
            this.folderNameLbl.Text = "Folder Name:";
            this.toolTip.SetToolTip(this.folderNameLbl, "The folder where the process should look the file.");
            // 
            // fileNameLbl
            // 
            this.fileNameLbl.AutoSize = true;
            this.fileNameLbl.Location = new System.Drawing.Point(18, 79);
            this.fileNameLbl.Name = "fileNameLbl";
            this.fileNameLbl.Size = new System.Drawing.Size(75, 17);
            this.fileNameLbl.TabIndex = 1;
            this.fileNameLbl.Text = "File Name:";
            this.toolTip.SetToolTip(this.fileNameLbl, "The file that the process should look for.");
            // 
            // frequencyLbl
            // 
            this.frequencyLbl.AutoSize = true;
            this.frequencyLbl.Location = new System.Drawing.Point(18, 127);
            this.frequencyLbl.Name = "frequencyLbl";
            this.frequencyLbl.Size = new System.Drawing.Size(79, 17);
            this.frequencyLbl.TabIndex = 2;
            this.frequencyLbl.Text = "Frequency:";
            this.toolTip.SetToolTip(this.frequencyLbl, "The frequency that the process should look for the file.");
            // 
            // notificationtypeLbl
            // 
            this.notificationtypeLbl.AutoSize = true;
            this.notificationtypeLbl.Location = new System.Drawing.Point(18, 170);
            this.notificationtypeLbl.Name = "notificationtypeLbl";
            this.notificationtypeLbl.Size = new System.Drawing.Size(118, 17);
            this.notificationtypeLbl.TabIndex = 3;
            this.notificationtypeLbl.Text = "Notification Type:";
            this.toolTip.SetToolTip(this.notificationtypeLbl, "The notification method type that the process will use to send notification\r\nin c" +
        "ase he couldn\'t find the file.");
            // 
            // deleteAfterReadLbl
            // 
            this.deleteAfterReadLbl.AutoSize = true;
            this.deleteAfterReadLbl.Location = new System.Drawing.Point(18, 212);
            this.deleteAfterReadLbl.Name = "deleteAfterReadLbl";
            this.deleteAfterReadLbl.Size = new System.Drawing.Size(125, 17);
            this.deleteAfterReadLbl.TabIndex = 4;
            this.deleteAfterReadLbl.Text = "Delete After Read:";
            this.toolTip.SetToolTip(this.deleteAfterReadLbl, "Indicate if the process should delete the file after he read it.");
            // 
            // notificationTypeTxt
            // 
            this.notificationTypeTxt.Enabled = false;
            this.notificationTypeTxt.Location = new System.Drawing.Point(142, 165);
            this.notificationTypeTxt.Name = "notificationTypeTxt";
            this.notificationTypeTxt.Size = new System.Drawing.Size(341, 22);
            this.notificationTypeTxt.TabIndex = 5;
            // 
            // frequencyTxt
            // 
            this.frequencyTxt.Enabled = false;
            this.frequencyTxt.Location = new System.Drawing.Point(140, 127);
            this.frequencyTxt.Name = "frequencyTxt";
            this.frequencyTxt.Size = new System.Drawing.Size(343, 22);
            this.frequencyTxt.TabIndex = 6;
            // 
            // fileNameTxt
            // 
            this.fileNameTxt.Enabled = false;
            this.fileNameTxt.Location = new System.Drawing.Point(140, 76);
            this.fileNameTxt.Name = "fileNameTxt";
            this.fileNameTxt.Size = new System.Drawing.Size(343, 22);
            this.fileNameTxt.TabIndex = 7;
            // 
            // folderNameTxt
            // 
            this.folderNameTxt.Enabled = false;
            this.folderNameTxt.Location = new System.Drawing.Point(142, 28);
            this.folderNameTxt.Name = "folderNameTxt";
            this.folderNameTxt.Size = new System.Drawing.Size(341, 22);
            this.folderNameTxt.TabIndex = 8;
            // 
            // deleteAfterReadCkb
            // 
            this.deleteAfterReadCkb.AutoSize = true;
            this.deleteAfterReadCkb.Enabled = false;
            this.deleteAfterReadCkb.Location = new System.Drawing.Point(142, 212);
            this.deleteAfterReadCkb.Name = "deleteAfterReadCkb";
            this.deleteAfterReadCkb.Size = new System.Drawing.Size(18, 17);
            this.deleteAfterReadCkb.TabIndex = 9;
            this.deleteAfterReadCkb.UseVisualStyleBackColor = true;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.btnedit);
            this.groupBox1.Controls.Add(this.folderNameLbl);
            this.groupBox1.Controls.Add(this.deleteAfterReadCkb);
            this.groupBox1.Controls.Add(this.folderNameTxt);
            this.groupBox1.Controls.Add(this.deleteAfterReadLbl);
            this.groupBox1.Controls.Add(this.notificationTypeTxt);
            this.groupBox1.Controls.Add(this.frequencyTxt);
            this.groupBox1.Controls.Add(this.fileNameTxt);
            this.groupBox1.Controls.Add(this.notificationtypeLbl);
            this.groupBox1.Controls.Add(this.fileNameLbl);
            this.groupBox1.Controls.Add(this.frequencyLbl);
            this.groupBox1.Location = new System.Drawing.Point(11, 16);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(492, 283);
            this.groupBox1.TabIndex = 10;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Target Machine Properties:";
            // 
            // btnedit
            // 
            this.btnedit.Location = new System.Drawing.Point(401, 243);
            this.btnedit.Name = "btnedit";
            this.btnedit.Size = new System.Drawing.Size(82, 34);
            this.btnedit.TabIndex = 10;
            this.btnedit.Text = "Edit";
            this.btnedit.UseVisualStyleBackColor = true;
            this.btnedit.Click += new System.EventHandler(this.btnedit_Click);
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.btnStop);
            this.groupBox2.Controls.Add(this.btnStart);
            this.groupBox2.Controls.Add(this.totalTrxTxt);
            this.groupBox2.Controls.Add(this.lastFailedtxt);
            this.groupBox2.Controls.Add(this.lastSuccessTxt);
            this.groupBox2.Controls.Add(this.stateTxt);
            this.groupBox2.Controls.Add(this.toalTrxLbl);
            this.groupBox2.Controls.Add(this.lastFailedLbl);
            this.groupBox2.Controls.Add(this.lastSuccessRead);
            this.groupBox2.Controls.Add(this.stateLbl);
            this.groupBox2.Location = new System.Drawing.Point(507, 17);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(316, 282);
            this.groupBox2.TabIndex = 11;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "States:";
            // 
            // btnStop
            // 
            this.btnStop.Enabled = false;
            this.btnStop.Location = new System.Drawing.Point(237, 242);
            this.btnStop.Name = "btnStop";
            this.btnStop.Size = new System.Drawing.Size(77, 34);
            this.btnStop.TabIndex = 18;
            this.btnStop.Text = "Stop";
            this.btnStop.UseVisualStyleBackColor = true;
            this.btnStop.Click += new System.EventHandler(this.btnStop_Click);
            // 
            // btnStart
            // 
            this.btnStart.Location = new System.Drawing.Point(153, 242);
            this.btnStart.Name = "btnStart";
            this.btnStart.Size = new System.Drawing.Size(78, 34);
            this.btnStart.TabIndex = 17;
            this.btnStart.Text = "Start";
            this.btnStart.UseVisualStyleBackColor = true;
            this.btnStart.Click += new System.EventHandler(this.btnStart_Click);
            // 
            // totalTrxTxt
            // 
            this.totalTrxTxt.AutoSize = true;
            this.totalTrxTxt.Location = new System.Drawing.Point(152, 170);
            this.totalTrxTxt.Name = "totalTrxTxt";
            this.totalTrxTxt.Size = new System.Drawing.Size(16, 17);
            this.totalTrxTxt.TabIndex = 16;
            this.totalTrxTxt.Text = "0";
            // 
            // lastFailedtxt
            // 
            this.lastFailedtxt.AutoSize = true;
            this.lastFailedtxt.Location = new System.Drawing.Point(152, 127);
            this.lastFailedtxt.Name = "lastFailedtxt";
            this.lastFailedtxt.Size = new System.Drawing.Size(31, 17);
            this.lastFailedtxt.TabIndex = 15;
            this.lastFailedtxt.Text = "N/A";
            // 
            // lastSuccessTxt
            // 
            this.lastSuccessTxt.AutoSize = true;
            this.lastSuccessTxt.Location = new System.Drawing.Point(152, 79);
            this.lastSuccessTxt.Name = "lastSuccessTxt";
            this.lastSuccessTxt.Size = new System.Drawing.Size(31, 17);
            this.lastSuccessTxt.TabIndex = 14;
            this.lastSuccessTxt.Text = "N/A";
            // 
            // stateTxt
            // 
            this.stateTxt.AutoSize = true;
            this.stateTxt.Location = new System.Drawing.Point(152, 28);
            this.stateTxt.Name = "stateTxt";
            this.stateTxt.Size = new System.Drawing.Size(61, 17);
            this.stateTxt.TabIndex = 13;
            this.stateTxt.Text = "Stopped";
            // 
            // toalTrxLbl
            // 
            this.toalTrxLbl.AutoSize = true;
            this.toalTrxLbl.Location = new System.Drawing.Point(8, 170);
            this.toalTrxLbl.Name = "toalTrxLbl";
            this.toalTrxLbl.Size = new System.Drawing.Size(130, 17);
            this.toalTrxLbl.TabIndex = 12;
            this.toalTrxLbl.Text = "Total Transactions:";
            // 
            // lastFailedLbl
            // 
            this.lastFailedLbl.AutoSize = true;
            this.lastFailedLbl.Location = new System.Drawing.Point(7, 127);
            this.lastFailedLbl.Name = "lastFailedLbl";
            this.lastFailedLbl.Size = new System.Drawing.Size(119, 17);
            this.lastFailedLbl.TabIndex = 11;
            this.lastFailedLbl.Text = "Last Failed Read:";
            // 
            // lastSuccessRead
            // 
            this.lastSuccessRead.AutoSize = true;
            this.lastSuccessRead.Location = new System.Drawing.Point(8, 79);
            this.lastSuccessRead.Name = "lastSuccessRead";
            this.lastSuccessRead.Size = new System.Drawing.Size(138, 17);
            this.lastSuccessRead.TabIndex = 1;
            this.lastSuccessRead.Text = "Last Success Read :";
            // 
            // stateLbl
            // 
            this.stateLbl.AutoSize = true;
            this.stateLbl.Location = new System.Drawing.Point(7, 28);
            this.stateLbl.Name = "stateLbl";
            this.stateLbl.Size = new System.Drawing.Size(45, 17);
            this.stateLbl.TabIndex = 0;
            this.stateLbl.Text = "State:";
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.eventListBox);
            this.groupBox3.Location = new System.Drawing.Point(16, 305);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(907, 230);
            this.groupBox3.TabIndex = 12;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Event Console:";
            // 
            // eventListBox
            // 
            this.eventListBox.FormattingEnabled = true;
            this.eventListBox.ItemHeight = 16;
            this.eventListBox.Location = new System.Drawing.Point(6, 21);
            this.eventListBox.Name = "eventListBox";
            this.eventListBox.Size = new System.Drawing.Size(799, 180);
            this.eventListBox.TabIndex = 0;
            // 
            // timer1
            // 
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // toolTip
            // 
            this.toolTip.ToolTipIcon = System.Windows.Forms.ToolTipIcon.Info;
            // 
            // TargetDetails
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.groupBox3);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Name = "TargetDetails";
            this.Size = new System.Drawing.Size(826, 517);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Label folderNameLbl;
        private System.Windows.Forms.Label fileNameLbl;
        private System.Windows.Forms.Label frequencyLbl;
        private System.Windows.Forms.Label notificationtypeLbl;
        private System.Windows.Forms.Label deleteAfterReadLbl;
        private System.Windows.Forms.TextBox notificationTypeTxt;
        private System.Windows.Forms.TextBox frequencyTxt;
        private System.Windows.Forms.TextBox fileNameTxt;
        private System.Windows.Forms.TextBox folderNameTxt;
        private System.Windows.Forms.CheckBox deleteAfterReadCkb;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Button btnedit;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.ListBox eventListBox;
        private System.Windows.Forms.Label lastFailedLbl;
        private System.Windows.Forms.Label stateLbl;
        private System.Windows.Forms.Label lastSuccessRead;
        private System.Windows.Forms.Label toalTrxLbl;
        private System.Windows.Forms.Label stateTxt;
        private System.Windows.Forms.Label lastSuccessTxt;
        private System.Windows.Forms.Label lastFailedtxt;
        private System.Windows.Forms.Label totalTrxTxt;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.Button btnStop;
        private System.Windows.Forms.Button btnStart;
        private System.Windows.Forms.ToolTip toolTip;
    }
}
