﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using sasa.common;
using sasa.cout;
using System.IO;

namespace Monitor
{
    public partial class SourceDetails : UserControl,MainFrame
    {
        private PropertiesCache cache = PropertiesCache.Instance;

        private SourcePropertiesValidator validator = new SourcePropertiesValidator();

        private static volatile SourceDetails instance;

        private static object syncRoot = new object();

        private string folderName;

        private string fileName;

        private bool overrideIfExist;

        private long totalTrx = 0;


        private SourceDetails()
        {
            InitializeComponent();
            InitializeValues(); 
        }

        private void InitializeTimer()
        {
            timer1.Interval = int.Parse(cache.ReadValueFromCache(PropertiesCache.SRC_FREQUENCY)) * 1000;
            folderName = cache.ReadValueFromCache(PropertiesCache.SRC_FILE_LOCATION);
            fileName = cache.ReadValueFromCache(PropertiesCache.SRC_FILE_NAME);
            overrideIfExist = isOverrideIfExist(cache.ReadValueFromCache(PropertiesCache.SRC_OVERRIDE_IF_EXIST));
        }


        public void ValidateProperties()
        {
            string message = validator.Validate();
            if (!"".Equals(message))
            {
                MessageBox.Show(message, "Invalid Installation Properties");
                MainForm.GetInstance().SetVaildateState(false);
                OpenPropertiesEdit();
            }
        }

        public void InitializeValues()
        {
            folderNameTxt.Text = cache.ReadValueFromCache(PropertiesCache.SRC_FILE_LOCATION);
            fileNameTxt.Text = cache.ReadValueFromCache(PropertiesCache.SRC_FILE_NAME);
            overrideCkbox.Checked = isOverrideIfExist(cache.ReadValueFromCache(PropertiesCache.SRC_OVERRIDE_IF_EXIST));
            frequencyTxt.Text = cache.ReadValueFromCache(PropertiesCache.SRC_FREQUENCY);
        }

        private bool isOverrideIfExist(string value)
        {
            if ("1".Equals(value))
            {
                return true;
            }
            return false;
        }


        private void OpenPropertiesEdit()
        {
            SourcePropertiesEdit propertiesEdit = new SourcePropertiesEdit();
            MainForm.GetInstance().SetActiveControl(propertiesEdit);
        }

        private void btnEdit_Click(object sender, EventArgs e)
        {
            OpenPropertiesEdit();
        }

        private void btnStart_Click(object sender, EventArgs e)
        {
            Start();
        }


        private void btnStop_Click(object sender, EventArgs e)
        {
            Stop();
        }

        public static SourceDetails Instance
        {
            get
            {
                if (instance == null)
                {
                    lock (syncRoot)
                    {
                        if (instance == null)
                            instance = new SourceDetails();
                    }
                }
                return instance;
            }
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            try
            {
                WriteFile();
                string now = DateTime.Now.ToString();
                string event1 = "[" + now + "]" + " File: " + fileName + " placed in folder: " + folderName;
                eventsListBox.Items.Insert(0, event1);
                totalTrx += 1;
                totaltrxTxt.Text = totalTrx.ToString();
                lastTrxTxt.Text = now;
            }
            catch (Exception)
            {
                string now = DateTime.Now.ToString();
                string event1 = "[" + now + "]" + "[ERROR]" + "Failed to write file: " + fileName + " in folder: " + folderName;
                eventsListBox.Items.Insert(0, event1);
            }
        }

        private void WriteFile()
        {
            CreateDir();
            CreateOrReplaceFile();
        }

        private void CreateOrReplaceFile()
        {
            String filePath = folderName + "/" + fileName;
            if (!File.Exists(filePath)){
                CreateFile(filePath);
            }else if (overrideIfExist)
            {
                DeleteFile(filePath);
                CreateFile(filePath);  
            }
        }

        private void DeleteFile(string filePath)
        {
            File.Delete(filePath);
        }

        private void CreateFile(string filePath)
        {
            using (StreamWriter sw = File.AppendText(filePath))
            {
                sw.WriteLine("ping");
            }
        }

        private void CreateDir()
        {
            if (Directory.Exists(folderName))
            {
                return;
            }
            DirectoryInfo di = Directory.CreateDirectory(folderName);
        }

        public void Start()
        {
            btnStop.Enabled = true;
            btnStart.Enabled = false;
            stateTxt.Text = "Running";
            InitializeTimer();
            timer1.Start();
            MainForm.GetInstance().EnableStart(false);
        }

        public void Stop()
        {
            btnStop.Enabled = false;
            btnStart.Enabled = true;
            stateTxt.Text = "Stopped";
            timer1.Stop();
            MainForm.GetInstance().EnableStart(true);
        }

        public void clearEventLogs()
        {
            eventsListBox.Items.Clear();
        }

        public void exportEventsToFile(string fileName)
        {
            EventsLogExporter.exportEventsToFile(fileName, eventsListBox.Items);
        }
    }
}
