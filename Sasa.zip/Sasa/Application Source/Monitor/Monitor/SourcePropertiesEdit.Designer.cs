﻿namespace Monitor
{
    partial class SourcePropertiesEdit
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.folderNameLbl = new System.Windows.Forms.Label();
            this.fileNameLbl = new System.Windows.Forms.Label();
            this.overrideLbl = new System.Windows.Forms.Label();
            this.frequencyLbl = new System.Windows.Forms.Label();
            this.folderNameTxt = new System.Windows.Forms.TextBox();
            this.fileNameTxt = new System.Windows.Forms.TextBox();
            this.frequencyTxt = new System.Windows.Forms.TextBox();
            this.overrideCkb = new System.Windows.Forms.CheckBox();
            this.btnBrowse = new System.Windows.Forms.Button();
            this.btnSave = new System.Windows.Forms.Button();
            this.btnCancel = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // folderNameLbl
            // 
            this.folderNameLbl.AutoSize = true;
            this.folderNameLbl.Location = new System.Drawing.Point(20, 32);
            this.folderNameLbl.Name = "folderNameLbl";
            this.folderNameLbl.Size = new System.Drawing.Size(93, 17);
            this.folderNameLbl.TabIndex = 0;
            this.folderNameLbl.Text = "Folder Name:";
            // 
            // fileNameLbl
            // 
            this.fileNameLbl.AutoSize = true;
            this.fileNameLbl.Location = new System.Drawing.Point(20, 78);
            this.fileNameLbl.Name = "fileNameLbl";
            this.fileNameLbl.Size = new System.Drawing.Size(75, 17);
            this.fileNameLbl.TabIndex = 1;
            this.fileNameLbl.Text = "File Name:";
            // 
            // overrideLbl
            // 
            this.overrideLbl.AutoSize = true;
            this.overrideLbl.Location = new System.Drawing.Point(20, 123);
            this.overrideLbl.Name = "overrideLbl";
            this.overrideLbl.Size = new System.Drawing.Size(111, 17);
            this.overrideLbl.TabIndex = 2;
            this.overrideLbl.Text = "Override If Exist:";
            // 
            // frequencyLbl
            // 
            this.frequencyLbl.AutoSize = true;
            this.frequencyLbl.Location = new System.Drawing.Point(20, 177);
            this.frequencyLbl.Name = "frequencyLbl";
            this.frequencyLbl.Size = new System.Drawing.Size(79, 17);
            this.frequencyLbl.TabIndex = 3;
            this.frequencyLbl.Text = "Frequency:";
            // 
            // folderNameTxt
            // 
            this.folderNameTxt.Enabled = false;
            this.folderNameTxt.Location = new System.Drawing.Point(138, 32);
            this.folderNameTxt.Name = "folderNameTxt";
            this.folderNameTxt.Size = new System.Drawing.Size(556, 22);
            this.folderNameTxt.TabIndex = 4;
            // 
            // fileNameTxt
            // 
            this.fileNameTxt.Location = new System.Drawing.Point(138, 78);
            this.fileNameTxt.Name = "fileNameTxt";
            this.fileNameTxt.Size = new System.Drawing.Size(556, 22);
            this.fileNameTxt.TabIndex = 5;
            // 
            // frequencyTxt
            // 
            this.frequencyTxt.Location = new System.Drawing.Point(138, 172);
            this.frequencyTxt.Name = "frequencyTxt";
            this.frequencyTxt.Size = new System.Drawing.Size(556, 22);
            this.frequencyTxt.TabIndex = 6;
            // 
            // overrideCkb
            // 
            this.overrideCkb.AutoSize = true;
            this.overrideCkb.Location = new System.Drawing.Point(138, 123);
            this.overrideCkb.Name = "overrideCkb";
            this.overrideCkb.Size = new System.Drawing.Size(18, 17);
            this.overrideCkb.TabIndex = 7;
            this.overrideCkb.UseVisualStyleBackColor = true;
            // 
            // btnBrowse
            // 
            this.btnBrowse.Location = new System.Drawing.Point(708, 32);
            this.btnBrowse.Name = "btnBrowse";
            this.btnBrowse.Size = new System.Drawing.Size(86, 23);
            this.btnBrowse.TabIndex = 8;
            this.btnBrowse.Text = "Browse";
            this.btnBrowse.UseVisualStyleBackColor = true;
            this.btnBrowse.Click += new System.EventHandler(this.btnBrowse_Click);
            // 
            // btnSave
            // 
            this.btnSave.Location = new System.Drawing.Point(608, 491);
            this.btnSave.Name = "btnSave";
            this.btnSave.Size = new System.Drawing.Size(86, 23);
            this.btnSave.TabIndex = 9;
            this.btnSave.Text = "Save";
            this.btnSave.UseVisualStyleBackColor = true;
            this.btnSave.Click += new System.EventHandler(this.btnSave_Click);
            // 
            // btnCancel
            // 
            this.btnCancel.Location = new System.Drawing.Point(708, 491);
            this.btnCancel.Name = "btnCancel";
            this.btnCancel.Size = new System.Drawing.Size(86, 23);
            this.btnCancel.TabIndex = 10;
            this.btnCancel.Text = "Cancel";
            this.btnCancel.UseVisualStyleBackColor = true;
            this.btnCancel.Click += new System.EventHandler(this.btnCancel_Click);
            // 
            // SourcePropertiesEdit
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.btnCancel);
            this.Controls.Add(this.btnSave);
            this.Controls.Add(this.btnBrowse);
            this.Controls.Add(this.overrideCkb);
            this.Controls.Add(this.frequencyTxt);
            this.Controls.Add(this.fileNameTxt);
            this.Controls.Add(this.folderNameTxt);
            this.Controls.Add(this.frequencyLbl);
            this.Controls.Add(this.overrideLbl);
            this.Controls.Add(this.fileNameLbl);
            this.Controls.Add(this.folderNameLbl);
            this.Name = "SourcePropertiesEdit";
            this.Size = new System.Drawing.Size(826, 517);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label folderNameLbl;
        private System.Windows.Forms.Label fileNameLbl;
        private System.Windows.Forms.Label overrideLbl;
        private System.Windows.Forms.Label frequencyLbl;
        private System.Windows.Forms.TextBox folderNameTxt;
        private System.Windows.Forms.TextBox fileNameTxt;
        private System.Windows.Forms.TextBox frequencyTxt;
        private System.Windows.Forms.CheckBox overrideCkb;
        private System.Windows.Forms.Button btnBrowse;
        private System.Windows.Forms.Button btnSave;
        private System.Windows.Forms.Button btnCancel;
    }
}
