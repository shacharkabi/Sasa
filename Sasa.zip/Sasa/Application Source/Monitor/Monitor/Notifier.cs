﻿using System;

namespace sasa.cin
{
    interface Notifier
    {
        Boolean SendNotification();
      
    }
}