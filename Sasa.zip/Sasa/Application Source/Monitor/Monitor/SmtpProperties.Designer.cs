﻿namespace Monitor
{
    partial class SmtpProperties
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.smtpHostLbl = new System.Windows.Forms.Label();
            this.smtpPortLbl = new System.Windows.Forms.Label();
            this.smtpUserLbl = new System.Windows.Forms.Label();
            this.smtpPasswordLbl = new System.Windows.Forms.Label();
            this.sendToEmailLbl = new System.Windows.Forms.Label();
            this.smtpHostTxt = new System.Windows.Forms.TextBox();
            this.smtpPortTxt = new System.Windows.Forms.TextBox();
            this.smtpUserTxt = new System.Windows.Forms.TextBox();
            this.smtpPasswordTxt = new System.Windows.Forms.TextBox();
            this.sendToEmailTxt = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // smtpHostLbl
            // 
            this.smtpHostLbl.AutoSize = true;
            this.smtpHostLbl.Location = new System.Drawing.Point(21, 17);
            this.smtpHostLbl.Name = "smtpHostLbl";
            this.smtpHostLbl.Size = new System.Drawing.Size(83, 17);
            this.smtpHostLbl.TabIndex = 0;
            this.smtpHostLbl.Text = "SMTP Host:";
            // 
            // smtpPortLbl
            // 
            this.smtpPortLbl.AutoSize = true;
            this.smtpPortLbl.Location = new System.Drawing.Point(21, 51);
            this.smtpPortLbl.Name = "smtpPortLbl";
            this.smtpPortLbl.Size = new System.Drawing.Size(80, 17);
            this.smtpPortLbl.TabIndex = 1;
            this.smtpPortLbl.Text = "SMTP Port:";
            // 
            // smtpUserLbl
            // 
            this.smtpUserLbl.AutoSize = true;
            this.smtpUserLbl.Location = new System.Drawing.Point(21, 87);
            this.smtpUserLbl.Name = "smtpUserLbl";
            this.smtpUserLbl.Size = new System.Drawing.Size(84, 17);
            this.smtpUserLbl.TabIndex = 2;
            this.smtpUserLbl.Text = "SMTP User:";
            // 
            // smtpPasswordLbl
            // 
            this.smtpPasswordLbl.AutoSize = true;
            this.smtpPasswordLbl.Location = new System.Drawing.Point(21, 122);
            this.smtpPasswordLbl.Name = "smtpPasswordLbl";
            this.smtpPasswordLbl.Size = new System.Drawing.Size(115, 17);
            this.smtpPasswordLbl.TabIndex = 3;
            this.smtpPasswordLbl.Text = "SMTP Password:";
            // 
            // sendToEmailLbl
            // 
            this.sendToEmailLbl.AutoSize = true;
            this.sendToEmailLbl.Location = new System.Drawing.Point(21, 160);
            this.sendToEmailLbl.Name = "sendToEmailLbl";
            this.sendToEmailLbl.Size = new System.Drawing.Size(101, 17);
            this.sendToEmailLbl.TabIndex = 4;
            this.sendToEmailLbl.Text = "Send To Emai:";
            // 
            // smtpHostTxt
            // 
            this.smtpHostTxt.Location = new System.Drawing.Point(152, 17);
            this.smtpHostTxt.Name = "smtpHostTxt";
            this.smtpHostTxt.Size = new System.Drawing.Size(495, 22);
            this.smtpHostTxt.TabIndex = 5;
            // 
            // smtpPortTxt
            // 
            this.smtpPortTxt.Location = new System.Drawing.Point(152, 48);
            this.smtpPortTxt.Name = "smtpPortTxt";
            this.smtpPortTxt.Size = new System.Drawing.Size(495, 22);
            this.smtpPortTxt.TabIndex = 6;
            // 
            // smtpUserTxt
            // 
            this.smtpUserTxt.Location = new System.Drawing.Point(152, 82);
            this.smtpUserTxt.Name = "smtpUserTxt";
            this.smtpUserTxt.Size = new System.Drawing.Size(495, 22);
            this.smtpUserTxt.TabIndex = 7;
            // 
            // smtpPasswordTxt
            // 
            this.smtpPasswordTxt.Location = new System.Drawing.Point(152, 117);
            this.smtpPasswordTxt.Name = "smtpPasswordTxt";
            this.smtpPasswordTxt.Size = new System.Drawing.Size(495, 22);
            this.smtpPasswordTxt.TabIndex = 8;
            // 
            // sendToEmailTxt
            // 
            this.sendToEmailTxt.Location = new System.Drawing.Point(152, 160);
            this.sendToEmailTxt.Name = "sendToEmailTxt";
            this.sendToEmailTxt.Size = new System.Drawing.Size(495, 22);
            this.sendToEmailTxt.TabIndex = 9;
            // 
            // SmtpProperties
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.Controls.Add(this.sendToEmailTxt);
            this.Controls.Add(this.smtpPasswordTxt);
            this.Controls.Add(this.smtpUserTxt);
            this.Controls.Add(this.smtpPortTxt);
            this.Controls.Add(this.smtpHostTxt);
            this.Controls.Add(this.sendToEmailLbl);
            this.Controls.Add(this.smtpPasswordLbl);
            this.Controls.Add(this.smtpUserLbl);
            this.Controls.Add(this.smtpPortLbl);
            this.Controls.Add(this.smtpHostLbl);
            this.Name = "SmtpProperties";
            this.Size = new System.Drawing.Size(669, 193);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label smtpHostLbl;
        private System.Windows.Forms.Label smtpPortLbl;
        private System.Windows.Forms.Label smtpUserLbl;
        private System.Windows.Forms.Label smtpPasswordLbl;
        private System.Windows.Forms.Label sendToEmailLbl;
        private System.Windows.Forms.TextBox smtpHostTxt;
        private System.Windows.Forms.TextBox smtpPortTxt;
        private System.Windows.Forms.TextBox smtpUserTxt;
        private System.Windows.Forms.TextBox smtpPasswordTxt;
        private System.Windows.Forms.TextBox sendToEmailTxt;
    }
}
