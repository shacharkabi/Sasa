﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using sasa.common;

namespace Monitor
{
    public partial class SyslogProperties : UserControl, NotifierDetails
    {
        private static SyslogProperties instance;

        private static object syncRoot = new object();

        private PropertiesCache cache = PropertiesCache.Instance;

        private SyslogProperties()
        {
            InitializeComponent();
            InitializeValues();
        }

        private void InitializeValues()
        {
            sysLogHostTxt.Text = cache.ReadValueFromCache(PropertiesCache.TARGET_SYSLOG_HOST);
            sysLogPortTxt.Text = cache.ReadValueFromCache(PropertiesCache.TARGET_SYSLOG_PORT);
    
        }

        public static SyslogProperties Instance
        {
            get
            {
                if (instance == null)
                {
                    lock (syncRoot)
                    {
                        if (instance == null)
                            instance = new SyslogProperties();
                    }
                }
                return instance;
            }
        }

        public void Save()
        {
            cache.UpdateProperty(PropertiesCache.TARGET_SYSLOG_HOST,sysLogHostTxt.Text);
            cache.UpdateProperty(PropertiesCache.TARGET_SYSLOG_PORT, sysLogPortTxt.Text);
        }
    }
}
