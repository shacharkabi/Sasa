﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using sasa.common;

namespace Monitor
{
    public partial class SnmpProperties : UserControl,NotifierDetails
    {
        private static SnmpProperties instance;

        private static object syncRoot = new object();

        private PropertiesCache cache = PropertiesCache.Instance;

        private SnmpProperties()
        {
            InitializeComponent();
            InitializeValues();
        }

        private void InitializeValues()
        {
            snmpHostTxt.Text = cache.ReadValueFromCache(PropertiesCache.TARGET_SNMP_HOST);
            snmpPortTxt.Text = cache.ReadValueFromCache(PropertiesCache.TARGET_SNMP_PORT);
        }

        public static SnmpProperties Instance
        {
            get
            {
                if (instance == null)
                {
                    lock (syncRoot)
                    {
                        if (instance == null)
                            instance = new SnmpProperties();
                    }
                }
                return instance;
            }
        }

        public void Save()
        {
            cache.UpdateProperty(PropertiesCache.TARGET_SNMP_HOST, snmpHostTxt.Text);
            cache.UpdateProperty(PropertiesCache.TARGET_SNMP_PORT, snmpPortTxt.Text);
        }
    }
}
