﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using sasa.cout;
using sasa.common;

namespace Monitor
{
    public partial class TargetPropertiesEdit : UserControl
    {
        TargetPropertiesValidator validator = new TargetPropertiesValidator();

        PropertiesCache propertiesCache = PropertiesCache.Instance;

        public TargetPropertiesEdit()
        {
            InitializeComponent();
            InitializeValues();
            MainForm.GetInstance().SetActiveControl(this);
        }

        public void InitializeValues()
        {
            folderNameTxt.Text = propertiesCache.ReadValueFromCache(PropertiesCache.TARGET_FILE_LOCATION);
            fileNameTxt.Text = propertiesCache.ReadValueFromCache(PropertiesCache.TARGET_FILE_NAME);
            deleteAfterReadCkb.Checked = IsDeleteAfterRead(propertiesCache.ReadValueFromCache(PropertiesCache.TARGET_DELETE_FILE));
            frequencyTxt.Text = propertiesCache.ReadValueFromCache(PropertiesCache.TARGET_FREQUENCY);
            notificationTypeCombo.SelectedText = propertiesCache.ReadValueFromCache(PropertiesCache.TARGET_NOTIFICATION_TYPE).ToUpper();
            SetNotificationDetailsPnl();

        }

        private bool IsDeleteAfterRead(string value)
        {
            if ("1".Equals(value))
            {
                return true;
            }
            return false;
        }

        private void browseBtn_Click(object sender, EventArgs e)
        {
            FolderBrowserDialog openFileDialog = new FolderBrowserDialog();
            if (openFileDialog.ShowDialog() == System.Windows.Forms.DialogResult.OK)
            {
                string path = openFileDialog.SelectedPath;
                folderNameTxt.Text = path;
            }
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            propertiesCache.UpdateProperty(PropertiesCache.TARGET_FILE_LOCATION, folderNameTxt.Text);
            propertiesCache.UpdateProperty(PropertiesCache.TARGET_FILE_NAME, fileNameTxt.Text);
            propertiesCache.UpdateProperty(PropertiesCache.TARGET_FREQUENCY, frequencyTxt.Text);
            propertiesCache.UpdateProperty(PropertiesCache.TARGET_NOTIFICATION_TYPE, notificationTypeCombo.Text);
            if (deleteAfterReadCkb.Checked)
            {
                propertiesCache.UpdateProperty(PropertiesCache.TARGET_DELETE_FILE, "1");
            }
            else
            {
                propertiesCache.UpdateProperty(PropertiesCache.TARGET_DELETE_FILE, "0");
            }
  
            NotifierFactory.GetNotifierDetails(notificationTypeCombo.Text).Save();
            string message = validator.Validate();
            if (!"".Equals(message))
            {
                MainForm.GetInstance().SetVaildateState(false);
                MessageBox.Show(message, "Invalid Installation Properties");
            }
            else
            {
                MainForm.GetInstance().SetVaildateState(true);
                TargetDetails.Instance.InitializeValues();
                MainForm.GetInstance().SetActiveControl(TargetDetails.Instance);
            }
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            string message = validator.Validate();
            if (!"".Equals(message))
            {
                MainForm.GetInstance().SetVaildateState(false);
                MessageBox.Show(message, "Invalid Installation Properties");
            }
            else
            {
                MainForm.GetInstance().SetVaildateState(true);
                MainForm.GetInstance().SetActiveControl(TargetDetails.Instance);
            }
        }

        private void notificationTypeCombo_SelectedIndexChanged(object sender, EventArgs e)
        {
            SetNotificationDetailsPnl();
           
        }

        private void SetNotificationDetailsPnl()
        {
            notificationDetailsPnl.Controls.Clear();
            notificationDetailsPnl.Controls.Add((Control)NotifierFactory.GetNotifierDetails(notificationTypeCombo.Text));
            notificationDetailsPnl.Text = notificationTypeCombo.Text + " Properties";
        }
    }
}
