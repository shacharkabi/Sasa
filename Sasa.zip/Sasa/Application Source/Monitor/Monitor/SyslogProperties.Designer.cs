﻿namespace Monitor
{
    partial class SyslogProperties
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.sysLogHostLbl = new System.Windows.Forms.Label();
            this.sysLogPortLbl = new System.Windows.Forms.Label();
            this.sysLogHostTxt = new System.Windows.Forms.TextBox();
            this.sysLogPortTxt = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // sysLogHostLbl
            // 
            this.sysLogHostLbl.AutoSize = true;
            this.sysLogHostLbl.Location = new System.Drawing.Point(21, 17);
            this.sysLogHostLbl.Name = "sysLogHostLbl";
            this.sysLogHostLbl.Size = new System.Drawing.Size(92, 17);
            this.sysLogHostLbl.TabIndex = 0;
            this.sysLogHostLbl.Text = "SysLog Host:";
            // 
            // sysLogPortLbl
            // 
            this.sysLogPortLbl.AutoSize = true;
            this.sysLogPortLbl.Location = new System.Drawing.Point(21, 54);
            this.sysLogPortLbl.Name = "sysLogPortLbl";
            this.sysLogPortLbl.Size = new System.Drawing.Size(89, 17);
            this.sysLogPortLbl.TabIndex = 1;
            this.sysLogPortLbl.Text = "SysLog Port:";
            // 
            // sysLogHostTxt
            // 
            this.sysLogHostTxt.Location = new System.Drawing.Point(152, 17);
            this.sysLogHostTxt.Name = "sysLogHostTxt";
            this.sysLogHostTxt.Size = new System.Drawing.Size(495, 22);
            this.sysLogHostTxt.TabIndex = 2;
            // 
            // sysLogPortTxt
            // 
            this.sysLogPortTxt.Location = new System.Drawing.Point(152, 51);
            this.sysLogPortTxt.Name = "sysLogPortTxt";
            this.sysLogPortTxt.Size = new System.Drawing.Size(495, 22);
            this.sysLogPortTxt.TabIndex = 3;
            // 
            // SyslogProperties
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.Controls.Add(this.sysLogPortTxt);
            this.Controls.Add(this.sysLogHostTxt);
            this.Controls.Add(this.sysLogPortLbl);
            this.Controls.Add(this.sysLogHostLbl);
            this.Name = "SyslogProperties";
            this.Size = new System.Drawing.Size(669, 193);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label sysLogHostLbl;
        private System.Windows.Forms.Label sysLogPortLbl;
        private System.Windows.Forms.TextBox sysLogHostTxt;
        private System.Windows.Forms.TextBox sysLogPortTxt;
    }
}
