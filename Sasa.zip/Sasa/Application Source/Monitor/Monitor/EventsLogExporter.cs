﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Monitor
{
    class EventsLogExporter
    {
        internal static void exportEventsToFile(string fileName, ListBox.ObjectCollection items)
        {
            if (File.Exists(fileName))
            {
                File.Delete(fileName);
            }
            using (StreamWriter sw = File.AppendText(fileName))
            {
                for(int i = 0; i < items.Count; i++) {
                    sw.WriteLine(items[i]);
                }
            }
        }
    }
}
