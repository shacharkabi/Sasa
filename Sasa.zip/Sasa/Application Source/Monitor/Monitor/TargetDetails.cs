﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using sasa.common;
using sasa.cin;
using System.IO;

namespace Monitor
{
    public partial class TargetDetails : UserControl,MainFrame
    {
        private PropertiesCache cache = PropertiesCache.Instance;

        private TargetPropertiesValidator validator = new TargetPropertiesValidator();

        private static TargetDetails instance;

        private static object syncRoot = new object();

        private string folderName;

        private string fileName;

        private bool deleteAfterRead;

        private long totalTrx = 0;


        private TargetDetails()
        {
            InitializeComponent();
            ValidateProperties();
            InitializeValues();
        }

        private void InitializeTimer()
        {
            timer1.Interval = int.Parse(cache.ReadValueFromCache(PropertiesCache.TARGET_FREQUENCY)) * 1000;
            folderName = cache.ReadValueFromCache(PropertiesCache.TARGET_FILE_LOCATION);
            fileName = cache.ReadValueFromCache(PropertiesCache.TARGET_FILE_NAME);
            deleteAfterRead = IsDeleteAfterRead(cache.ReadValueFromCache(PropertiesCache.TARGET_DELETE_FILE));
        }


        public void ValidateProperties()
        {
            string message = validator.Validate();
            if (!"".Equals(message))
            {
                MessageBox.Show(message, "Invalid Installation Properties");
                MainForm.GetInstance().SetVaildateState(false);
                OpenPropertiesEdit();
            }
        }

        public void InitializeValues()
        {
            folderNameTxt.Text = cache.ReadValueFromCache(PropertiesCache.TARGET_FILE_LOCATION);
            fileNameTxt.Text = cache.ReadValueFromCache(PropertiesCache.TARGET_FILE_NAME);
            deleteAfterReadCkb.Checked = IsDeleteAfterRead(cache.ReadValueFromCache(PropertiesCache.TARGET_DELETE_FILE));
            frequencyTxt.Text = cache.ReadValueFromCache(PropertiesCache.TARGET_FREQUENCY);
            notificationTypeTxt.Text = cache.ReadValueFromCache(PropertiesCache.TARGET_NOTIFICATION_TYPE).ToUpper();
        }

        private void OpenPropertiesEdit()
        {
            TargetPropertiesEdit propertiesEdit = new TargetPropertiesEdit();
            MainForm.GetInstance().SetActiveControl(propertiesEdit);
        }

        private bool IsDeleteAfterRead(string value)
        {
            if ("1".Equals(value))
            {
                return true;
            }
            return false;
        }



        private void timer1_Tick(object sender, EventArgs e)
        {
            try
            {
                ReadFile();
                string now = DateTime.Now.ToString();
                string event1 = "[" + now + "]" + " File: " + fileName + " found in folder: " + folderName;
                eventListBox.Items.Insert(0, event1);
                totalTrx += 1;
                totalTrxTxt.Text = totalTrx.ToString();
                lastSuccessTxt.Text = now;
            }
            catch (MonitorReadException)
            {
                string now = DateTime.Now.ToString();
                string event1 = "[" + now + "]" + "[ERROR]" + "File: " + fileName + " not found in folder: " + folderName;
                eventListBox.Items.Insert(0, event1);
                lastFailedtxt.Text = now;
                Notifier notifier = NotifierFactory.GetNotifier(cache.ReadValueFromCache(PropertiesCache.TARGET_NOTIFICATION_TYPE));
                bool isNotificationSent = notifier.SendNotification();
                if (!isNotificationSent)
                {
                    string event2 = "[" + now + "]" + "[ERROR] Failed to sent notification - Please check Notification details";
                    eventListBox.Items.Insert(0, event2);
                }
            }
            catch (Exception)
            {
                string now = DateTime.Now.ToString();
                string event1 = "[" + now + "]" + "[ERROR]" + "Failed to write file: " + fileName + " in folder: " + folderName;
                eventListBox.Items.Insert(0, event1);
            }
        }

        private void ReadFile()
        {
            String filePath = folderName + "/" + fileName;
            if (!File.Exists(filePath))
            {
                throw new MonitorReadException();
            }
            if (deleteAfterRead)
            {
                File.Delete(filePath);
            }
        }

        private void btnStart_Click(object sender, EventArgs e)
        {
            Start();
        }

        private void btnStop_Click(object sender, EventArgs e)
        {
            Stop();
        }

        public static TargetDetails Instance
        {
            get
            {
                if (instance == null)
                {
                    lock (syncRoot)
                    {
                        if (instance == null)
                            instance = new TargetDetails();
                    }
                }
                return instance;
            }
        }

        public void Start()
        {
            btnStop.Enabled = true;
            btnStart.Enabled = false;
            stateTxt.Text = "Running";
            InitializeTimer();
            timer1.Start();
            MainForm.GetInstance().EnableStart(false);
        }

        public void Stop()
        {
            btnStop.Enabled = false;
            btnStart.Enabled = true;
            stateTxt.Text = "Stopped";
            timer1.Stop();
            MainForm.GetInstance().EnableStart(true);
        }

        private void btnedit_Click(object sender, EventArgs e)
        {
            OpenPropertiesEdit();
        }

        public void clearEventLogs()
        {
            eventListBox.Items.Clear();
        }

        public void exportEventsToFile(string fileName)
        {
            EventsLogExporter.exportEventsToFile(fileName, eventListBox.Items);
        }
    }
}
